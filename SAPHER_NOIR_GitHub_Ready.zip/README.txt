SAPHER NOIR — PROFESSIONAL E-COMMERCE V2

Run locally:
1. Install Node.js 18+.
2. Open a terminal in this folder.
3. Run: npm install
4. Run: npm start
5. Open: http://localhost:3000
6. Admin demo: http://localhost:3000/admin.html

Included:
- Responsive luxury storefront
- Supplied SAPHER NOIR logo + product image
- Product catalog loaded from products.json
- Product sizes
- Persistent browser cart
- Checkout form
- Cash on Delivery order creation
- Server-side order storage in orders.json
- Demo order dashboard
- eSewa and Khalti payment-method placeholders

REAL PAYMENT INTEGRATION:
eSewa and Khalti require merchant onboarding/credentials. Do not put secret keys in browser JavaScript.
For production, connect the server to the merchant APIs and verify callbacks/status before marking an order paid.

NEXT PRODUCTION ITEMS:
- Real product photos for each SKU
- Secure admin authentication
- Database (PostgreSQL/MySQL)
- Inventory/stock updates
- Shipping zones/rates
- eSewa merchant integration
- Khalti merchant integration
- Email/SMS order notifications
- Refund/return workflow
- Domain + HTTPS + deployment
- Analytics and Meta/TikTok tracking
