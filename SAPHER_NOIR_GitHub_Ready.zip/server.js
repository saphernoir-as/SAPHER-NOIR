const express = require("express");
const path = require("path");
const fs = require("fs");
const app = express();
const PORT = process.env.PORT || 3000;
const ROOT = __dirname;
const ORDERS = path.join(ROOT, "orders.json");

app.use(express.json());
app.use(express.static(path.join(ROOT, "public")));

function readOrders(){
  if(!fs.existsSync(ORDERS)) fs.writeFileSync(ORDERS, "[]");
  return JSON.parse(fs.readFileSync(ORDERS, "utf8"));
}
function writeOrders(orders){
  fs.writeFileSync(ORDERS, JSON.stringify(orders, null, 2));
}

app.get("/api/products", (req,res)=>{
  res.json(JSON.parse(fs.readFileSync(path.join(ROOT,"products.json"),"utf8")));
});

app.post("/api/orders", (req,res)=>{
  const {customer, items, paymentMethod} = req.body || {};
  if(!customer || !customer.name || !customer.phone || !customer.address || !Array.isArray(items) || !items.length){
    return res.status(400).json({error:"Missing checkout information."});
  }
  const total = items.reduce((sum,item)=>sum + Number(item.price||0)*Number(item.qty||1), 0);
  const orders = readOrders();
  const order = {
    id: "SN-" + Date.now().toString(36).toUpperCase(),
    createdAt: new Date().toISOString(),
    status: paymentMethod === "cod" ? "COD_PENDING" : "PAYMENT_PENDING",
    paymentMethod,
    total,
    customer,
    items
  };
  orders.push(order);
  writeOrders(orders);
  res.status(201).json({orderId: order.id, total, status: order.status});
});

app.get("/api/admin/orders", (req,res)=>{
  // Demo/admin endpoint. Protect this route with real authentication before production.
  res.json(readOrders().reverse());
});

app.get("/api/health", (req,res)=>res.json({ok:true, brand:"SAPHER NOIR"}));

app.listen(PORT, ()=>console.log(`SAPHER NOIR store running on http://localhost:${PORT}`));
