# SAPHER NOIR — Render Deployment

1. Upload the contents of this folder to the root of the GitHub repository.
2. In Render, choose **New > Web Service** and connect the GitHub repository.
3. Build Command: `npm install`
4. Start Command: `npm start`
5. The app listens on Render's `PORT` environment variable.

Important:
- The current admin endpoint is a demo and is NOT production-secure.
- Do not add eSewa/Khalti secret keys to frontend files or GitHub.
- Before accepting real payments/orders, add server-side authentication, a persistent database, payment verification/webhooks, and production security controls.
